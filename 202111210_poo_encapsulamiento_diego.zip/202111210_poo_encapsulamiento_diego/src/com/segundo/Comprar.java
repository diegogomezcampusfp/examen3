package com.segundo;

import com.primero.Coche;

public class Comprar {

	public static void main(String[] args) {
		
		Coche coche1 = new Coche(1,"Audi", 5.200f);
		Coche coche2 = new Coche(2,"Ford", 6.100f);
		Coche coche3 = new Coche(3,"Kia", 7.355f);
		Coche coche4 = new Coche(4,"BMW", 8.800f);

		System.out.println (coche3.getPrecio());
	}

}
